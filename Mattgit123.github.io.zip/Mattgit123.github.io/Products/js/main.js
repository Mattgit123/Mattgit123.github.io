/*
Name: Matt Tounkara
Date: 03/06/2018
Description: This is my final project for Web Development 100 @ NYCDA in Philadelphia.
             the aim of this project is to create an e-commerce shoe store website.
             A website where you can shop for the finest and most elegant shoes you
             could ever come across. A one stop shopping place for shoes. This is
             the main.js for the Products page. Its purpose is to apply javascript
             and jQuery to the index.html of the Products page. */


$(document).ready(function() {


        $("#theMessage").animate({right: '200px'}, "slow");
        $("#theMessage").fadeOut(2000);
        $("#theMessage").fadeIn(2000);
        $("#theMessage").animate({left: '200px'}, "slow");
        $("#theMessage").fadeOut(2000);
        $("#theMessage").fadeIn(2000);
        $("#theMessage").animate({left: '-10px'}, "slow");
        $("#theMessage").fadeOut(2000);
        $("#theMessage").fadeIn(2000);

});
